
import java.io.BufferedInputStream;
import java.io.File;  //takes file path
import java.io.FileInputStream; // takes files contents
import java.io.IOException;
import java.nio.file.Path;  
import java.nio.file.Paths;  // to cjheck if path is empty
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;



public class mainClass {
     private String filename;
    public static String pathOfsong;
     public static String nameOfSong;
    public String fileLocation;
    private Player player; 
    public int pause1=0;
    public long pauseLocation;
    public long songTotalLength;
    FileInputStream FIS ;
    BufferedInputStream BIS ;
    LinkedList llist = new LinkedList();
    static int index = 1; 
    
 
 
    public mainClass() {
        
        
        Path currentRelativePath = Paths.get("");
        String s = currentRelativePath.toAbsolutePath().toString() +"\\Music\\";
            pathOfsong = s;
            
        try {
            
            File folder = new File(s); 
            listFilesForFolder(folder);
        }
        catch(Exception e) {
            System.out.println("");
        }
              
    }
    public void nullPlayerObject(){
        player = null;
    }
 
  public void stop(){
        if(player!=null)
        {
            player.close();
            songTotalLength = 0;
            pauseLocation   = 0;
            player = null;
        }
      }
  public void next()
  {
     
      if(index >llist.count()-1)
      { 
          index = 0;
      }                   //index stays less then count-1
          if(index<0)            //index stays grtr then 0
          {
              index = 0;
          }
         
       String song =llist.printNode(index);
       stop();
       play(song);
       nameOfSong = song;
       index++;
      
      
       
      
  }
   public void previus()
  {
      index--;
      if(index <0)                //index stays grtr then 0
      {
          index = llist.count()-1;
      }
      String song =llist.printNode(index);
      
       stop();
       play(song);
       nameOfSong = song;
      
      
  }
   public static void listFilesForFolder( File folder)
	{
		
		
    for ( File fileEntry : folder.listFiles())
	{
        if (fileEntry.isDirectory())
		{
            listFilesForFolder(fileEntry);
        }
            else
            {
                
                String fileName = fileEntry.getName();
                
                String f = "test.txt";
                if(fileName.equals(f))
                {
                    System.out.print("File Found");
                }
                else
                {
                 String song = pathOfsong+fileName;
                LinkedList.add(song);
                }

            }
    }
    
}
   public String p()
   {
       return pathOfsong;
   }
    public String p1()
   {
       return nameOfSong;
   }
   
   public void addSong(String song)
    {
        LinkedList.add(song);
    }
  public void pause(){
        if(player!=null)
        {
            pause1=0;
             
            try {
                   
                    pauseLocation = FIS.available();
                    player.close();
            } catch (IOException ex) {
                
            }
        }
        }
      public void resume() { 
          if(pause1==0)
          {
              pause1=1;
          if(player!=null)
              
 try {   
      FIS = new FileInputStream(fileLocation);
      BIS = new BufferedInputStream(FIS);
      player = new Player(BIS);
    
      FIS.skip(songTotalLength-pauseLocation);  //skip to paused location
    
      
 }
 catch (JavaLayerException | IOException e) {
 
     System.out.println(e);
 }
         
  new Thread()
 {
        @Override
        public void run()
        {
            try {
                 
                player.play();
            } catch (JavaLayerException ex) {
               
            }
        }
}.start();

}
      }
  
  
  
  
  
    public void play(String filename1) {
        
        if(player==null){
 try {   
     FIS = new FileInputStream(filename1);
     BIS = new BufferedInputStream(FIS);
     player = new Player(BIS);
   
     songTotalLength = FIS.available();
     
     fileLocation = filename1 + "";
    
       
 }

 catch (Exception e) {
 
     System.out.println("Exception2");
 }
  new Thread()
 {
        @Override
        public void run()
        {
            try {
                
                player.play();
            } catch (JavaLayerException ex) {
               
            }
        }
        
}.start();

    }
        else resume();}}