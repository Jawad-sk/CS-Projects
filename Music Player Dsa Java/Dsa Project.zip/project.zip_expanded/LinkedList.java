
public class LinkedList {
        
	static Node head;
	
        int count = 0;
	
	static class Node
	{
		String data;
		Node next;
		Node prev;
		public Node(String odata){
			data = odata;
			next = null;
			prev = null;
		}
		
	
	}
	
    static void add(String new_data)
    {
        
    Node new_node = new Node(new_data);
         
    Node last = head;
    
    new_node.next = null;
         
    
    if(head == null)
    {
        new_node.prev = null;
        head = new_node;
        return;
    }
         
    
    while(last.next != null)
        last = last.next;
         
    
    last.next = new_node;
         
    
    new_node.prev = last;
    }
	
	
	
	
    public int count()
    {
        count = 0;
        Node current = head;
        while(current!= null)
        {
               
                current = current.next;
                count++;
        }
        return count;
    }
	
	public String printNode(int d)
	{
		int index=0;
		Node current = head;
		for(int i=0;i<=d;i++)
		{
			if(d==index){
				
                                return current.data;	
			}
			current = current.next;
			index++;
		}
                return " ";
	}
}